import React, { useState, useEffect, useRef } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";
import "./StoryTale.css"; // Add CSS for loading spinner

const StoryTale = () => {
  const { storyID } = useParams();
  const navigate = useNavigate();
  const [title, setTitle] = useState(""); // Story title
  const [storyIDState, setStoryIDState] = useState(storyID ? parseInt(storyID, 10) : 0); //base 10
  const [stories, setStories] = useState([]); // List of stories in the table
  const [isLoading, setIsLoading] = useState(false); // For loading indicator
  const hasFetched = useRef(false);

  // Fetch existing story details
  useEffect(() => {
    if (storyIDState !== 0 && !hasFetched.current) {
      hasFetched.current = true;
      setIsLoading(true);
      axios
        .get(`http://localhost:8080/API/stories/${storyIDState}`, { withCredentials: true })
        .then((response) => {
          setTitle(response.data.storyTitle || "");
          setStoryIDState(response.data.storyId);
          const sortedStories = (response.data.storyLines || []).sort((a, b) => a.id - b.id);
          setStories(sortedStories);
        })
        .catch((error) => console.error("Error fetching story data:", error))
        .finally(() => setIsLoading(false));
    }
  }, [storyIDState]);

  // Save title
  const saveTitle = () => {
    if (!title.trim()) {
      alert("Title cannot be empty!");
      return;
    }

    setIsLoading(true);
    axios
      .post(`http://localhost:8080/API/stories/${storyIDState}/title/${title}`, {}, { withCredentials: true })
      .then((response) => {
        setStoryIDState(response.data);
        alert("Title saved successfully!");
        navigate(`/storytale/${response.data}`);
      })
      .catch((error) => console.error("Error saving title:", error))
      .finally(() => setIsLoading(false));
  };

  // Add a new row
  const addNewRow = () => {
    const newId = stories.length > 0 ? stories[stories.length - 1].id + 1 : 1;
    setStories([...stories, { id: newId,imagePrompt:"", storyLine: "", storyImage: "" }]);
  };

  // Handle text change in story rows
  const handleStoryTextChange = (index, event) => {
    const updatedStories = [...stories];
    updatedStories[index].storyLine = event.target.value;
    setStories(updatedStories);
  };
  // Handle Image prompt in story rows
  const handleImagePromptChange = (index, event) => {
    const updatedStories = [...stories];
    updatedStories[index].imagePrompt = event.target.value;
    setStories(updatedStories);
  };

  // Handle generate/save/delete actions
  const handleActionChange = (lineId, index, action) => {
    const story = stories[index];
    const storyText = story?.storyLine || "";
    const imagePrompt = story?.imagePrompt || "";
  
    if (action === "generate") {
      if (!imagePrompt.trim()) {
        alert(`Row ${index + 1} has an empty image prompt! Please add text.`);
        return;
      }
  
      setIsLoading(true);
      axios
        .get(
          `http://localhost:8080/API/stories/${storyIDState}/image/${index}/${encodeURIComponent(imagePrompt)}`,
          {
            responseType: "text",
            withCredentials: true,
          }
        )
        .then((response) => {
          const base64Image = response.data;
          const updatedStories = [...stories];
          updatedStories[index].storyImage = base64Image;
          setStories(updatedStories);
          alert(`Image generated for row ${index + 1}!`);
        })
        .catch((error) => console.error("Error generating image:", error))
        .finally(() => setIsLoading(false));
    } else if (action === "save") {
      if (!storyText.trim()) {
        alert(`Row ${index + 1} has an empty story line! Please add text.`);
        return;
      }
  
      axios
        .post(
          `http://localhost:8080/API/stories/${storyIDState}/content/${index}/${encodeURIComponent(storyText)}`,
          {},
          { withCredentials: true }
        )
        .then(() => alert(`Row ${index + 1} saved successfully!`))
        .catch((error) => console.error("Error saving row:", error));
    } else if (action === "delete") {
      axios
        .delete(`http://localhost:8080/API/stories/${storyIDState}/section/${index}`, { withCredentials: true })
        .then(() => {
          alert(`Row ${index + 1} deleted successfully!`);
          setStories(stories.filter((_, rowIndex) => rowIndex !== index));
        })
        .catch((error) => console.error("Error deleting row:", error));
    }
  };
  
  const handlePreviewClick = () => {
    navigate(`/preview/${storyIDState}`);
  };

  return (
    <div className="container">
      {isLoading && (
        <div className="loading-overlay">
          <div className="spinner-border text-primary" role="status">
            <span className="sr-only">Loading...</span>
          </div>
        </div>
      )}
      <h2>{storyIDState === 0 ? "Create New Story" : "Edit Story"}</h2>

      <table className="table" style={{ tableLayout: "fixed", width: "100%" }}>
        <thead>
          <tr>
            <th style={{ width: "20%" }}>Story ID</th>
            <th style={{ width: "60%" }}>Story Title</th>
            <th style={{ width: "10%" }}>Action</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>
              <input type="text" className="form-control" value={storyIDState} readOnly />
            </td>
            <td>
              <input
                type="text"
                className="form-control"
                placeholder="Enter Story Title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
              />
            </td>
            <td>
              <button className="btn btn-primary" onClick={saveTitle}>
                {storyIDState === 0 ? "Add Title" : "Save Title"}
              </button>
            </td>
          </tr>
        </tbody>
      </table>

      <h3>Story Lines</h3>
      <table className="table" style={{ tableLayout: "fixed", width: "100%" }}>
        <thead>
          <tr>
            <th style={{ width: "3%" }}>No.</th>
            <th style={{ width: "45%" }}>Image</th>
            <th style={{ width: "40%" }}>Story</th>
            <th style={{ width: "10%" }}>Action</th>
          </tr>
        </thead>
        <tbody>
          {stories.map((story, index) => (
            <tr key={index}>
              <td>{index + 1}</td>
              <td>
                <img
                  src={
                    story.storyImage
                      ? `data:image/jpeg;base64,${story.storyImage}`
                      : "https://via.placeholder.com/100"
                  }
                  alt={`Story ${story.id}`}
                  style={{ width: "300px", height: "auto" }}
                />
              </td>
              <td>
                <b>Image Prompt</b>
                <textarea
                  className="form-control"
                  placeholder="Enter Image Prompt"
                  value={story.imagePrompt}
                  onChange={(e) => handleImagePromptChange(index, e)}
                  rows={3}
                />
                <b>Story Line</b>
                <textarea
                  className="form-control"
                  placeholder="Enter story line"
                  value={story.storyLine}
                  onChange={(e) => handleStoryTextChange(index, e)}
                  rows={3}
                />
              </td>
              <td>
                <select
                  className="form-control form-control-sm"
                  onChange={(e) => handleActionChange(story.id, index, e.target.value)}
                >
                  <option value="">Select Action</option>
                  <option value="generate">Generate</option>
                  <option value="save">Save</option>
                  <option value="delete">Delete</option>
                </select>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <button className="btn btn-primary" onClick={addNewRow}>
        +
      </button>
      <br />
      <button className="btn btn-success mt-3" onClick={handlePreviewClick}>
        Preview
      </button>
    </div>
  );
};

export default StoryTale;
